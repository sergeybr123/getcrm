<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\User;
use App\Models\Company;
use App\Models\Phone;
use App\Models\Bot;
use App\Models\Account;
use App\Models\Profile;
use PragmaRX\Countries\Package\Countries;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::with('phone')->orderBy('id', 'desc')->paginate(30);
        return view('manager.users.index', ['users' => $users]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        $bots = Company::where('user_id', $id)->whereNotNull('bot')->whereNull('deleted_at')->get();
        $pages = Company::where('user_id', $id)->whereNull('bot')->whereNull('deleted_at')->get();
        return view('manager.users.show', ['user' => $user, 'bots' => $bots, 'pages' => $pages]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
//        $cou = Countries::all();
//        foreach ($cou as $c)
//            dd($c);
//        dd($cou->KAZ->dialling);
        return view('manager.users.edit', ['user' => $user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request, [
            'id' => 'required|numeric',
            'email' => [
                'required',
                'email',
//                Rule::unique('users')->ignore($request->id)
            ],
            'country_code' => 'required',
            'phone' => [
                'required',
                'numeric',
//                Rule::unique('phones')->ignore($request->id, 'user_id')
            ]
        ]);

        $user = User::findOrFail($request->id);

        $user->email = $request->email;

        $country_code = explode('-', $request->country_code);
        $cca2 = $country_code[0];
        $code = $country_code[0];

        $phone = $user->phone()->first();
        if (!$phone) {
            $phone = new Phone();
            $phone->user_id = $user->id;
        }
        $phone->cca2 = $cca2;
        $phone->country_code = $code;
        $phone->phone = $request->phone;

        if (
            $request->has('first_name') ||
            $request->has('last_name') ||
            $request->has('company') ||
            $request->has('location')
        ) {
            $user->profile()->save(Profile::updateOrCreate(
                ['user_id' => $user->id],
                [
                    'first_name' => $request->input('first_name'),
                    'last_name' => $request->input('last_name'),
                    'company' => $request->input('company'),
                    'location' => $request->input('location'),
                ]
            ));
        }

        $phone->save();
        $user->save();

        return back()->with(['success' => 'Данные сохранились']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /*Подписка на бесплатный пакет пользователей не имеющих авточат*/
    public function selectNotSubscribed()
    {
//        set_time_limit(0);
        /*Раскомментировать рабочий код, не удалять*/
        $users = Company::whereNull('bot')->whereNull('deleted_at')->select('user_id')->distinct()->get();
        foreach ($users as $user) {
            if(Bot::where('botable_id', $user->user_id)->doesntExist())
            {
                $url = 'http://billing/api/subscribe/free/'.$user->user_id;
                $headers = array(
                    'Content-Type:application/json',
                    'Authorization: Basic Zm94X3JpdGVrQG1haWwucnU6U2VyZ2V5QA=='
                );
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $data = curl_exec($ch);
                curl_close($ch);
                print_r($data);
            }
        }
    }
}
