@extends('layouts.app')

@section('title', __('Счета и платежи'))

@section('styles')
<link href="{{ asset('vendors/css/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
    <style>
        #DataTables_Table_0_wrapper {
            padding: 8px 0 0 0;
        }
    </style>
@endsection

@section('content')

    <h1>{{ __('Счета и платежи') }}</h1>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            {{--<div class="px-3">--}}
                {{--Фильтр--}}
            {{--</div>--}}

            <table class="table table-bordered dataTable">
                <thead>
                <tr>
                    <th width="70">#</th>
                    <th>Пользователь</th>
                    <th width="110">Тип платежа</th>
                    <th width="80">Сумма</th>
                    <th width="50">Оплата</th>
                    <th width="100">Дата создания</th>
                    {{--<th width="50"></th>--}}
                </tr>
                </thead>
                <tbody>
                @forelse($invoices as $key => $invoice)
                <tr>
                    <td>
                        {{ $invoice[1]->id }}
                    </td>
                    <td>
                        {{ $invoice[0]['email'] }}
                    </td>
                    <td class="text-center">
                        {{ $invoice[1]->types->name }}
                    </td>
                    <td class="text-right">
                        {{ number_format($invoice[1]->amount, 0, '.', '') }} тг.
                    </td>
                    <td class="text-center">
                        @if($invoice[1]->paid == 0)
                            <span class="badge badge-danger">Нет</span>
                        @else
                            <span class="badge badge-success">Да</span>
                        @endif
                    </td>
                    <td class="text-center">
                        {{ \Carbon\Carbon::parse($invoice[1]->created_at)->format('d.m.Y') }}
                    </td>
                    {{--<td></td>--}}
                </tr>
                @empty
                @endforelse
                </tbody>

            </table>

        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{ __('pages.change_owner') }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')

    <script src="{{ asset('vendors/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('vendors/js/dataTables.bootstrap4.min.js') }}"></script>
    <script>
        $('.dataTable').DataTable({
            "order": [[ 0, "desc" ]],
            "lengthMenu": [[30, 50, 100, -1], [30, 50, 100, "Все"]],
            "pagingType": "full_numbers",
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"
            }
        });
        $('.dataTable').attr('style','border-collapse: collapse !important');
        // $('#DataTables_Table_0_filter').empty();



        {{--let str = '';
        let page = 1;
        let url = '';
        Load(page)

        function Load(page) {
            url = "http://billing/api/invoice?page=" + page;
            $.ajax
            ({
                type: "GET",
                url: url,
                dataType: 'json',
                async: false,
                headers: {
                    "Authorization": "Basic " + "{{ env('BILLING_TOKEN') }}"
                },
                success: function (request){
                    // console.log(request.data[0].options.plan_id);
                    console.log(request);
                    // $.each(request.data, function(key, value) {
                    //     str += '<li class="list-group-item"><div class="d-flex w-100 justify-content-between">';
                    //
                    //     str += '<h5 class="mb-1">' + value.id + '</h5>';
                    //     // str += '<li class="list-group-item">';
                    //     // str += '<li class="list-group-item">';
                    //     // str += '<li class="list-group-item">';
                    //     // str += '<li class="list-group-item">';
                    //     // str += '<li class="list-group-item">';
                    //
                    //     str += '</div></li>';
                    // });

                    // $('#invoices').append(str);
                    // $('#current_page').text('Текущая страница: ' + request.meta.current_page);
                    // $('#total').text('Показано записей: c ' + request.meta.from + ' по ' + request.meta.to + ' из ' + request.meta.total + ' записей');
                }
            });
        }--}}

        // function copyPageToClipboard(key) {
        //     var $temp = $("<input>");
        //     $("body").append($temp);
        //     $temp.val($('#page_slug_' + key).text()).select();
        //     document.execCommand("copy");
        //     $temp.remove();
        //     toastr.info('Ссылка скопирована');
        // }
    </script>
@endsection