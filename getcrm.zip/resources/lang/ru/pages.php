<?php
return [
    'pages' => 'Страницы',
    'link' => 'Ссылка',
    'owner' => 'Владелец',
    'change_owner' => 'Изменить владельца',
];