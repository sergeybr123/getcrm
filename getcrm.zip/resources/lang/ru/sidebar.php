<?php
return [
    'dictionary' => 'Справочники',
    'activity' => 'Сфера деятельности',
    'dashboard' => 'Dashboard',
    'control' => 'Управление',
    'users' => 'Пользователи',
    'invoices' => 'Счета',
    'bots' => 'Авточаты',
    'pages' => 'Страницы',
    'subscriptions' => 'Подписки',
    'swap_bots' => 'Заменить авточат',
    'analytics' => 'Аналитика',
    'income' => 'Доходы',
    'invoices_pay' => 'Счета и оплаты',
];