<?php
return [
    'users' => 'Пользователи',
    'users_list' => 'Список пользователей',
    'email' => 'Email',
    'phone' => 'Телефон',
    'register_at' => 'Дата регистрации',
];