<?php
return [
    'view' => 'Смотреть',
    'share' => 'Поделиться',
    'back' => 'Назад',
    'save' => 'Сохранить',
    'cancel' => 'Отмена',
    'remove' => 'Удалить',
    'create_in_constructor' => 'Создать в конструкторе',
    'change_owner' => 'Изменить владельца',
    'copy_link' => 'Копировать ссылку',
    'link' => 'Ссылка',
    'close' => 'Закрыть',
];