<?php $__env->startSection('title', __('users.users')); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-blue"><?php echo e(__('buttons.back')); ?></a>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div class="px-3">
                <h2><?php echo e($page->slug); ?></h2>
            </div>
        </div>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <div>
                    
                        
                        
                    
                    <div class="form-group mb-0">
                        <label for="">Email пользователя: </label>
                        <strong><?php echo e($page->owner->email); ?></strong>
                    </div>
                </div>
                <div>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-blue ml-1" type="button" id="dropdownMenuButton"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                style="border-radius:50%;width:30px;height:30px;">
                            <i class="fa fa-ellipsis-v"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#"><i class="far fa-eye"></i> <?php echo e(__('buttons.view')); ?></a>
                            <a class="dropdown-item" href="#" onclick=""><i class="fa fa-copy"></i> <?php echo e(__('buttons.share')); ?></a>
                            <a class="dropdown-item text-danger" href="#"><i class="fa fa-trash"></i> <?php echo e(__('buttons.remove')); ?></a>
                        </div>
                    </div>
                    
                        
                        
                        
                        
                    
                </div>
            </div>

        </div>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div>
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($account->type); ?></h5>
                                <small class="text-muted" title="Дата создания">
                                    <?php echo e(\Carbon\Carbon::parse($account->created_at)->format('d.m.Y')); ?>

                                </small>
                            </div>
                            <div class="">
                                <?php $__currentLoopData = $account->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="mr-2"><?php echo e($key); ?>: <?php echo e($val); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item">Авточаты отсутствуют</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('pages.change_owner')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    function copyToClipboard(key) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($('#slug_' + key).text()).select();
        document.execCommand("copy");
        $temp.remove();
        toastr.info('Ссылка скопирована');
    }
    function copyPageToClipboard(key) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($('#page_slug_' + key).text()).select();
        document.execCommand("copy");
        $temp.remove();
        toastr.info('Ссылка скопирована');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>