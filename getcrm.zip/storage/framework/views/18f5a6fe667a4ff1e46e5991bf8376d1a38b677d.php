<?php $__env->startSection('title', __('users.users')); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo e(__('users.users')); ?></h1>
<div class="card card-accent-primary mt-3">
    <div class="card-body">
        <div class="px-3">
            Фильтр
        </div>
        <ul class="list-group mb-3">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item">
                    <div class="d-flex w-100 justify-content-between">
                        <a href="<?php echo e(route('manager.users.show', ['id' => $item->id])); ?>"><?php echo e($item->email); ?></a>
                        <small class="text-muted" title="<?php echo e(__('users.register_at')); ?>">
                            <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d.m.Y')); ?>

                        </small>
                    </div>
                    <div class="d-flex w-100 justify-content-between">
                        <div class="mt-2">
                            <strong><i class="fa fa-hashtag"></i></strong><?php echo e($item->id); ?>

                            <strong class="ml-3"><?php echo e(__('Телефон')); ?>: </strong>
                            <span>
                                <?php if($item->phone != null): ?>
                                    +<?php echo e($item->phone->country_code . $item->phone->phone); ?>

                                <?php else: ?>
                                    <span>Нет номера</span>
                                <?php endif; ?>
                            </span>
                        </div>
                        
                            
                                
                            
                            
                                
                                        
                                        
                                        
                                    
                                
                                
                                    
                                        
                                    
                                
                            
                        
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item">Страницы отсутствуют</li>
            <?php endif; ?>
        </ul>
        <div class="px-3">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>