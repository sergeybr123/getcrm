<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <?php if (app('laratrust')->hasRole('admin')) : ?>
            
                
                    
                
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.plans.index')); ?>">
                    <i><i class="fa fa-clipboard-list"></i></i> <?php echo e(__('Тарифные планы')); ?>

                </a>
            </li>
            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#">
                    <i><i class="fa fa-database"></i></i> <?php echo app('translator')->getFromJson('sidebar.dictionary'); ?>
                </a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i><i class="fa fa-minus"></i></i> <?php echo app('translator')->getFromJson('sidebar.activity'); ?>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
            <?php if (app('laratrust')->hasRole('admin|manager')) : ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i><i class="fa fa-tachometer-alt"></i></i> <?php echo app('translator')->getFromJson('sidebar.dashboard'); ?>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('manager.users.index')); ?>">
                    <i><i class="fa fa-users"></i></i> <?php echo app('translator')->getFromJson('sidebar.users'); ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('manager.pages.index')); ?>">
                    <i><i class="fa fa-copy"></i></i> <?php echo app('translator')->getFromJson('sidebar.pages'); ?>
                </a>
            </li>
            
                
                    
                
            

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#">
                    <i><i class="fa fa-comments"></i></i> <?php echo e(__('sidebar.bots')); ?>

                </a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('manager/bots/old')); ?>">
                            <i><i class="far fa-circle"></i></i> <?php echo e(__('Старые')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('manager/bots/new')); ?>">
                            <i><i class="far fa-circle"></i></i> <?php echo e(__('Новые')); ?>

                        </a>
                    </li>
                </ul>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('manager.invoices.index')); ?>">
                    <i><i class="fa fa-file-invoice"></i></i> <?php echo app('translator')->getFromJson('sidebar.invoices'); ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i><i class="fa fa-exchange-alt" aria-hidden="true"></i></i> <?php echo app('translator')->getFromJson('sidebar.swap_bots'); ?>
                </a>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
            <?php if (app('laratrust')->hasRole('partner')) : ?>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="icon-bubble"></i> <?php echo app('translator')->getFromJson('sidebar.bots'); ?>
                </a>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
            <?php if (app('laratrust')->hasRole('analyst')) : ?>
            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#">
                    <i><i class="fa fa-signature"></i></i> <?php echo e(__('sidebar.analytics')); ?>

                </a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i><i class="fa fa-clipboard-list"></i></i> <?php echo e(__('sidebar.subscriptions')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i><i class="fa fa-donate"></i></i> <?php echo e(__('sidebar.income')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i><i class="fa fa-file-invoice"></i></i> <?php echo e(__('sidebar.invoices_pay')); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; // app('laratrust')->hasRole ?>
        </ul>
    </nav>
    <div class="text-center py-3" style="background-color:#36a9e1;">
        <span>GETCHAT.ME © 2016-<?php echo e(date('Y')); ?></span>
    </div>
</div>