<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('vendors/css/flag-icon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendors/css/simple-line-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('vendors/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/bootstrap.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>