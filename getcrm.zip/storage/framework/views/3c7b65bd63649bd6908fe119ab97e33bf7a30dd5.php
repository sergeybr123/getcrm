<?php $__env->startSection('title', __('')); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <a href="<?php echo e(route('manager.users.show', $user->id)); ?>" class="btn btn-outline-blue"><i
                    class="fa fa-angle-double-left"></i> <?php echo e(__('Назад')); ?></a>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="card card-accent-primary mt-3">
                <div class="card-header">
                    <p class="h3 text-center"><?php echo e($user->email); ?></p>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('manager.users.update', $user)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">


                        <?php if(session('success')): ?>
                            <p class="text-success">
                                <?php echo e(session('success')); ?>

                            </p>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="text-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                        <div class="form-group row">
                            <label for="email" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e($user->email); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="country_code" class="col-sm-2 col-form-label">Код</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="country_code" name="country_code" placeholder="country_code" value="<?php echo e($user->phone->country_code); ?>">
                                
                                    
                                    
                                    
                                
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="phone" class="col-sm-2 col-form-label">Телефон</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="Email" value="<?php echo e($user->phone->phone); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Имя</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="first_name" placeholder="Имя" value="<?php echo e($user->profile != null ? $user->profile->first_name : ''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="surname" class="col-sm-2 col-form-label">Фамилия</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="surname" name="last_name" placeholder="Фамилия" value="<?php echo e($user->profile != null ? $user->profile->last_name : ''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="company" class="col-sm-2 col-form-label">Компания</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="company" name="company" placeholder="Компания" value="<?php echo e($user->profile != null ? $user->profile->company : ''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="location" class="col-sm-2 col-form-label">Городо, стр</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="location" name="location" placeholder="Городо, стр" value="<?php echo e($user->profile != null ? $user->profile->location : ''); ?>">
                            </div>
                        </div>
                        <div>
                            <button type="submit">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>