<?php $__env->startSection('title', __('users.users')); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-blue"><i
                    class="fa fa-angle-double-left"></i> <?php echo e(__('Назад')); ?></a>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div class="d-flex w-100 justify-content-between">
                <div>
                    <h2><?php echo e($user->email); ?></h2>
                    <div>
                        <strong>Телефон: </strong>
                        <?php if($user->phone): ?>
                            +<?php echo e($user->phone->country_code . $user->phone->phone); ?>

                        <?php else: ?>
                            Номер отсутствует
                        <?php endif; ?>
                    </div>
                    <div>
                        <strong>Дата
                            регистрации: </strong><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d.m.Y')); ?>

                    </div>
                </div>
                <div class="form-inline" style="align-items: normal;">
                    <a href="<?php echo e(route('manager.users.edit', ['id' => $user->id])); ?>" class="btn btn-sm btn-outline-blue" style="border-radius:50%;width:30px;height:30px;"
                       title="<?php echo e(__('Редактировать')); ?>">
                        <i class="fa fa-pencil-alt"></i>
                    </a>
                    <a href="#" class="btn btn-sm btn-outline-blue ml-1"
                       style="border-radius:50%;width:30px;height:30px;" data-toggle="modal" data-target="#invoiceModal"
                       title="Выставить счет" onclick="Load();">
                        <i class="fa fa-file-invoice"></i>
                    </a>
                    <a href="#" class="btn btn-sm btn-outline-blue ml-1" style="border-radius:50%;width:30px;height:30px;"
                       title="Добавить авточат">
                        <i class="fa fa-comments"></i>
                    </a>
                    
                        
                                
                                
                            
                        
                        
                            
                            
                                    
                        
                    
                </div>
            </div>
        </div>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div>
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $bots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($bot->name ?? $bot->slug); ?></h5>
                                <small class="text-muted" title="Дата создания">
                                    <?php echo e(\Carbon\Carbon::parse($bot->created_at)->format('d.m.Y')); ?>

                                </small>
                            </div>
                            <div class="d-flex w-100 justify-content-between">
                                <p class="mb-1">
                                    <span id="slug_<?php echo e($key); ?>">https://getchat.me/<?php echo e($bot->slug); ?></span>
                                    <button class="btn btn-sm btn-outline-blue ml-2" type="button"
                                            title="Копировать ссылку"
                                            onclick="copyToClipboard(<?php echo e($key); ?>)" style="border-radius:50%;">
                                        <i class="fa fa-copy"></i>
                                    </button>
                                </p>
                                <div class="form-inline">
                                    <a href="#" class="btn btn-sm btn-outline-blue" style="border-radius:50%;">
                                        <i class="fa fa-pencil-alt"></i>
                                    </a>
                                    
                                    
                                    
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-blue ml-1" type="button"
                                                id="dropdownMenuButton"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                                style="border-radius:50%;width:30px;height:30px;">
                                            <i class="fa fa-ellipsis-v"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right"
                                             aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="https://getchat.me/<?php echo e($bot->slug); ?>"
                                               target="_blank"><i class="far fa-eye"></i> <?php echo e(__('buttons.view')); ?></a>
                                            <a class="dropdown-item" href="#" onclick="copyToClipboard(<?php echo e($key); ?>)"><i
                                                        class="fa fa-copy"></i> <?php echo e(__('buttons.copy_link')); ?></a>
                                            <a class="dropdown-item text-danger" href="#"><i
                                                        class="fa fa-trash"></i> <?php echo e(__('buttons.remove')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item">Авточаты отсутствуют</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div>
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo e($page->slug); ?></h5>
                                <small class="text-muted" title="Дата создания">
                                    <?php echo e(\Carbon\Carbon::parse($page->created_at)->format('d.m.Y')); ?>

                                </small>
                            </div>
                            <div class="d-flex w-100 justify-content-between">
                                <p class="mb-1">
                                    <span id="page_slug_<?php echo e($key); ?>">https://getchat.me/<?php echo e($page->slug); ?></span>
                                    <button class="btn btn-sm btn-outline-blue ml-2" type="button"
                                            title="Копировать ссылку"
                                            onclick="copyPageToClipboard(<?php echo e($key); ?>)" style="border-radius:50%;">
                                        <i class="fa fa-copy"></i>
                                    </button>
                                </p>
                                <div class="form-inline">
                                    <a href="#" class="btn btn-sm btn-outline-blue" style="border-radius:50%;">
                                        <i class="fa fa-pencil-alt"></i>
                                    </a>
                                    
                                    
                                    
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-blue ml-1" type="button"
                                                id="dropdownMenuButton"
                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                                style="border-radius:50%;width:30px;height:30px;">
                                            <i class="fa fa-ellipsis-v"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right"
                                             aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="https://getchat.me/<?php echo e($page->slug); ?>"
                                               target="_blank"><i class="far fa-eye"></i> <?php echo e(__('buttons.view')); ?></a>
                                            <a class="dropdown-item" href="#" onclick="copyPageToClipboard(<?php echo e($key); ?>)"><i
                                                        class="fa fa-copy"></i> <?php echo e(__('buttons.copy_link')); ?></a>
                                            <a class="dropdown-item text-danger" href="#"><i
                                                        class="fa fa-trash"></i> <?php echo e(__('buttons.remove')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item">Авточаты отсутствуют</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>




    <div class="modal fade" id="invoiceModal" tabindex="-1" role="dialog" aria-labelledby="invoiceModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Выставить счет</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="plan_place"></div>
                    <div class="mt-3" id="amount_place">
                        <strong>Итого: </strong><span id="amount">0</span>
                    </div>
                    <textarea id="description" class="form-control mt-2" rows="3" placeholder="Описание(не обязательно)"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="CloseForm()">Отмена</button>
                    <button type="button" class="btn btn-primary" onclick="PostForm()">Сохранить</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function copyToClipboard(key) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($('#slug_' + key).text()).select();
            document.execCommand("copy");
            $temp.remove();
            toastr.info('Ссылка скопирована');
        }

        function copyPageToClipboard(key) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($('#page_slug_' + key).text()).select();
            document.execCommand("copy");
            $temp.remove();
            toastr.info('Ссылка скопирована');
        }


        /*-----------------------Выставление счета------------------------------*/
        let typeId = null;
        let planId = null;
        let serviceId = null;
        let amount = 0;
        let planAmount = 0;
        let serviceAmount = 0;
        let subscribeAmount = 0;
        let url = '';
        let strPlan = '';
        let strService = '';

        function Load()
        {
            let str = '';
            $('#plan_place').empty();
            $.ajax({
                type: "GET",
                url: "http://billing/api/type-invoice",
                dataType: 'json',
                async: false,
                headers: {
                    "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                },
                success: function (request) {
                    str += '<strong>Тип счета:</strong>';
                    $.each(request, function (key, value) {
                        str += '<div class="form-check">';
                        str += '    <input class="form-check-input" type="radio" onclick="ChoiseType(' + value.id + ')" name="type_id" id="typeRadios' + key + '" value="' + value.id + '">';
                        str += '    <label class="form-check-label" for="typeRadios' + key + '">' + value.name + '</label>';
                        str += '</div>';
                    });
                    $('#plan_place').append(str);
                    str = '';


                }
            });
        }

        function ChoiseType(id)
        {
            typeId = id;
            strPlan = '';
            strService = '';
            $('#planPlace').remove(); // Удаляем если имеется
            $('#servicePlace').remove();
            planAmount = 0;
            serviceAmount = 0;
            subscribeAmount = 0;

            if(id == 1) {
                $.ajax({
                    type: "GET",
                    url: "http://billing/api/subscribe/" + '<?php echo e($user->id); ?>',
                    dataType: 'json',
                    async: false,
                    headers: {
                        "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                    },
                    success: function (request) {
                        // strService += '<div class="mt-2" id="servicePlace">';
                        // strService += '<strong>Услуги:</strong>';
                        // $.each(request, function (key, value) {
                        //     strService += '<div class="form-check">';
                        //     strService += '    <input class="form-check-input" type="radio" name="service_id" onclick="ChoiseService('+value.id+', '+value.price+')" id="serviceRadios'+key+'" value="'+value.id+'">';
                        //     strService += '    <label class="form-check-label" for="serviceRadios'+key+'">'+value.name+'</label>';
                        //     strService += '</div>';
                        // });
                        // strService += '</div>';
                        // $('#plan_place').append(strService);
                        // strService = '';
                        console.log(request.data/*.plan.name + ', ' +request.data.plan.price*/)
                        subscribeAmount = parseInt(parseFloat(request.data.plan.price).toFixed(0)) || 0;
                    }
                });
            }

            if(id == 2) {
                $.ajax({
                    type: "GET",
                    url: "http://billing/api/plans",
                    dataType: 'json',
                    async: false,
                    headers: {
                        "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                    },
                    success: function (request) {
                        strPlan += '<div class="mt-2" id="planPlace">';
                        strPlan += '<strong>Тарифный план:</strong>';
                        $.each(request.data, function (key, value) {
                            strPlan += '<div class="form-check">';
                            strPlan += '    <input class="form-check-input" type="radio" name="plan_id" onclick="ChoisePlan('+value.id+', \''+value.code+'\', '+value.price+')" id="plansRadios' + key + '" value="' + value.id + '">';
                            strPlan += '    <label class="form-check-label" for="plansRadios' + key + '">' + value.name + '</label>';
                            strPlan += '</div>';
                        });
                        strPlan += '<div class="form-check mt-3">' +
                                  '    <input class="form-check-input" type="checkbox" id="developChat" onclick="ChoiseDevelop()">' +
                                  '    <label class="form-check-label" for="developChat">Разработка авточата</label>' +
                                  '</div>';
                        strPlan += '</div>';
                        $('#plan_place').append(strPlan);
                        strPlan = '';
                    }
                });
                $('#plan_place').append(strService);
            }
            if(id == 3) {
                $.ajax({
                    type: "GET",
                    url: "http://billing/api/services",
                    dataType: 'json',
                    async: false,
                    headers: {
                        "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                    },
                    success: function (request) {
                        strService += '<div class="mt-2" id="servicePlace">';
                        strService += '<strong>Услуги:</strong>';
                        $.each(request, function (key, value) {
                            strService += '<div class="form-check">';
                            strService += '    <input class="form-check-input" type="radio" name="service_id" onclick="ChoiseService('+value.id+', '+value.price+')" id="serviceRadios'+key+'" value="'+value.id+'">';
                            strService += '    <label class="form-check-label" for="serviceRadios'+key+'">'+value.name+'</label>';
                            strService += '</div>';
                        });
                        strService += '</div>';
                        $('#plan_place').append(strService);
                        strService = '';
                    }
                });
            }

            Itogo();
        }

        function ChoisePlan(id, code, price)
        {
            planAmount = 0;
            serviceAmount = 0;
            planId = id;
            planAmount +=  price;
            Itogo();
            LoadServices()
        }

        function ChoiseDevelop()
        {
            LoadServices();
        }

        function LoadServices()
        {
            strService = '';
            url = '';
            $('#servicePlace').remove();
            if($('#developChat').is(':checked')) {
                if(planId === 1) {
                    url = "http://billing/api/service/plan-not-null";
                } else {
                    url = "http://billing/api/service/" + planId + "/plan";
                }
                $.ajax({
                    type: "GET",
                    url: url,
                    dataType: 'json',
                    async: false,
                    headers: {
                        "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                    },
                    success: function (request) {
                        strService += '<div class="mt-2" id="servicePlace">';
                        strService += '<strong>Услуги:</strong>';
                        $.each(request, function (key, value) {
                            strService += '<div class="form-check">';
                            strService += '    <input class="form-check-input" type="radio" name="service_id" onclick="ChoiseService('+value.id+', '+value.price+')" id="serviceRadios'+key+'" value="'+value.id+'">';
                            strService += '    <label class="form-check-label" for="serviceRadios'+key+'">'+value.name+'</label>';
                            strService += '</div>';
                        });
                        strService += '</div>';
                        $('#plan_place').append(strService);
                        strService = '';
                    }
                });
            } else {
                $('#servicePlace').remove();
                serviceAmount = 0;
                Itogo();
            }
        }

        function ChoiseService(id, price)
        {
            serviceAmount = 0;
            serviceId = id;
            serviceAmount += price;
            Itogo();
        }

        function Itogo()
        {
            amount = subscribeAmount + planAmount + serviceAmount;
            $('#amount').text(amount);
        }

        // Отправка данных на сервер
        function PostForm()
        {
            let data = {
                manager_id: '<?php echo e(Auth::user()->id); ?>',
                user_id: '<?php echo e($user->id); ?>',
                amount: amount,
                type_id: typeId,
                plan_id: planId,
                service_id: serviceId,
                description: $('#description').val()
            };
            $.ajax({
                type: "POST",
                url: "http://billing/api/invoice",
                data: data,
                dataType: 'json',
                headers: {
                    "Authorization": "Basic " + "<?php echo e(env('BILLING_TOKEN')); ?>"
                },
                success: function (request) {
                    if(request.error == 0) {
                        CloseForm();
                    }
                }
            });
        }

        // Закрытие формы
        function CloseForm()
        {
            typeId = 0;
            planId = 0;
            serviceId = 0;
            amount = 0;
            planAmount = 0;
            serviceAmount = 0;
            url = '';
            strPlan = '';
            strService = '';
            $('#planPlace').remove();
            $('#servicePlace').remove();
            Itogo();
            $('#invoiceModal').modal('hide')
        }
        /*-----------------------Выставление счета------------------------------*/
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>