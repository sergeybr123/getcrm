<?php $__env->startSection('title', __('users.users')); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e(__('Авточаты новые')); ?> (<?php echo e(count($bots_new)); ?>)</h1>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            <div class="px-3">
                Фильтр
            </div>
            <ul class="list-group mb-3">
                <?php $__empty_1 = true; $__currentLoopData = $bots_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $botn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo e($botn->name); ?></h5>
                            <span id="bot_link_<?php echo e($key); ?>" style="display: none;">https://getchat.me/<?php echo e($botn->company->slug); ?></span>
                            <small class="text-muted" title="Дата создания">
                                <?php echo e(\Carbon\Carbon::parse($botn->created_at)->format('d.m.Y')); ?>

                            </small>
                        </div>
                        <div class="d-flex w-100 justify-content-between">
                            <p class="mb-1">
                                <strong><?php echo e(__('pages.owner')); ?>: </strong>
                                <a href="<?php echo e(route('manager.users.show', ['id' => $botn->company->owner->id])); ?>"><?php echo e($botn->company->owner->email); ?></a>
                            </p>
                            <div class="form-inline">
                                <a href="#" class="btn btn-circle btn-sm btn-outline-blue">
                                    <i class="fa fa-pencil-alt"></i>
                                </a>
                                <div class="dropdown">
                                    <button class="btn btn-circle btn-sm btn-outline-blue ml-1" type="button" id="dropdownMenuButton"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                            style="width:30px;height:30px;">
                                        <i class="fa fa-ellipsis-v"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="https://getchat.me/<?php echo e($botn->company->slug); ?>" target="_blank"><i class="far fa-eye"></i> <?php echo e(__('buttons.view')); ?></a>
                                        <button class="dropdown-item" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-exchange-alt"></i> <?php echo e(__('buttons.change_owner')); ?></button>
                                        <a class="dropdown-item" href="#" onclick="copyBotToClipboard(<?php echo e($key); ?>)"><i class="fa fa-copy"></i> <?php echo e(__('buttons.copy_link')); ?></a>
                                        <a class="dropdown-item text-danger" href="#"><i class="fa fa-trash"></i> <?php echo e(__('buttons.remove')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item">Авточаты отсутствуют</li>
                <?php endif; ?>
            </ul>
            <div class="px-3">
                <?php echo e($bots_new->links()); ?>

            </div>
        </div>
    </div>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('pages.change_owner')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function copyBotToClipboard(key) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($('#bot_link_' + key).text()).select();
            document.execCommand("copy");
            $temp.remove();
            toastr.info('Ссылка скопирована');
        }
        function copyPageToClipboard(key) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($('#page_slug_' + key).text()).select();
            document.execCommand("copy");
            $temp.remove();
            toastr.info('Ссылка скопирована');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>