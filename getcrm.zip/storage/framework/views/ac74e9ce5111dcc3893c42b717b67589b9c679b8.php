<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="<?php echo e(asset('/img/logo/logo.png')); ?>" type="image/x-icon">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>
        <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            <?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'GetCRM')); ?>

        <?php else: ?>
            <?php echo e(config('app.name', 'GetCRM')); ?>

        <?php endif; ?>
    </title>
    <link href="<?php echo e(asset('vendors/css/flag-icon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendors/css/simple-line-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body id="app" class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
<header class="app-header navbar">
    <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button">
        <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>"><span>GetCRM</span></a>
    <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button">
        <span class="navbar-toggler-icon"></span>
    </button>
    <ul class="nav navbar-nav d-md-down-none mr-auto">

    </ul>
    <ul class="nav navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a class="nav-link nav-link mr-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <i class="far fa-user-circle" style="font-size: 34px;"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <div class="dropdown-header text-center">
                    <strong>Управление</strong>
                </div>
                <a class="dropdown-item" href="#"><i class="fa fa-user"></i> Профиль</a>
                <a class="dropdown-item" href="#"><i class="fa fa-wrench"></i> Настройки</a>
                <a class="dropdown-item" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-lock"></i> Выйти</a>
            </div>
        </li>
    </ul>
</header>
<div class="app-body">
    <?php echo $__env->make('layouts.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main class="main">
        <div class="container-fluid">
            <div class="animated fadeIn">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </main>
</div>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form>
<script src="<?php echo e(asset('vendors/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/pace.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app_simple.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/gauge.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/moment.min.js')); ?>"></script>

<script>
    $(function () {
        $('[data-tooltip="tooltip"]').tooltip()
    })
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>