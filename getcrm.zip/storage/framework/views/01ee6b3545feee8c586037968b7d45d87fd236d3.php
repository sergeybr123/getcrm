<?php $__env->startSection('title', __('Счета и платежи')); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendors/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <style>
        #DataTables_Table_0_wrapper {
            padding: 8px 0 0 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1><?php echo e(__('Счета и платежи')); ?></h1>
    <div class="card card-accent-primary mt-3">
        <div class="card-body">
            
                
            

            <table class="table table-bordered dataTable">
                <thead>
                <tr>
                    <th width="70">#</th>
                    <th>Пользователь</th>
                    <th width="110">Тип платежа</th>
                    <th width="80">Сумма</th>
                    <th width="50">Оплата</th>
                    <th width="100">Дата создания</th>
                    
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e($invoice[1]->id); ?>

                    </td>
                    <td>
                        <?php echo e($invoice[0]['email']); ?>

                    </td>
                    <td class="text-center">
                        <?php echo e($invoice[1]->types->name); ?>

                    </td>
                    <td class="text-right">
                        <?php echo e(number_format($invoice[1]->amount, 0, '.', '')); ?> тг.
                    </td>
                    <td class="text-center">
                        <?php if($invoice[1]->paid == 0): ?>
                            <span class="badge badge-danger">Нет</span>
                        <?php else: ?>
                            <span class="badge badge-success">Да</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php echo e(\Carbon\Carbon::parse($invoice[1]->created_at)->format('d.m.Y')); ?>

                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>

            </table>

        </div>
    </div>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('pages.change_owner')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('vendors/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script>
        $('.dataTable').DataTable({
            "order": [[ 0, "desc" ]],
            "lengthMenu": [[30, 50, 100, -1], [30, 50, 100, "Все"]],
            "pagingType": "full_numbers",
            "language": {
                "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Russian.json"
            }
        });
        $('.dataTable').attr('style','border-collapse: collapse !important');
        // $('#DataTables_Table_0_filter').empty();



        

        // function copyPageToClipboard(key) {
        //     var $temp = $("<input>");
        //     $("body").append($temp);
        //     $temp.val($('#page_slug_' + key).text()).select();
        //     document.execCommand("copy");
        //     $temp.remove();
        //     toastr.info('Ссылка скопирована');
        // }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>